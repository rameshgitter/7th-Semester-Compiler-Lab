
int main(){
    // int a;
    int a = 5;
    printf("Hello World");
    return 0;
}